This is the profile of Chaoquan Jiang
